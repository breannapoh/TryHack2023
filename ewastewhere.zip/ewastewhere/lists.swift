//
//  lists.swift
//  ewastewhere
//
//  Created by Breanna Poh on 12/10/23.
//

import Foundation

let threein1: [String] = [
"3-in-1"
]
