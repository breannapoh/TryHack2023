//
//  ewastewhereApp.swift
//  ewastewhere
//
//  Created by Breanna Poh on 12/10/23.
//

import SwiftUI

@main
struct ewastewhereApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
